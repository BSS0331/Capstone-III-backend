import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import RecipesScreen from '../screens/RecipesScreen';
import FridgeScreen from '../screens/FridgeScreen';
import SettingScreen from '../screens/SettingScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// FAB 스택 자식 네비게이터
const HomeStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false, // 스택 네비게이터의 헤더를 숨김
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="설정" component={SettingScreen} />
    </Stack.Navigator>
  );
};

// 하단 네비게이터
const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {  // Expo Icon
          let iconName;
          if (route.name === '메인메뉴') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === '레시피') {
            iconName = focused ? 'book' : 'book-outline';
          } else if (route.name === '냉장고') {
            iconName = focused ? 'restaurant' : 'restaurant-outline';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
      tabBarOptions={{
        activeTintColor: 'tomato',
        inactiveTintColor: 'gray',
      }}
    >
      <Tab.Screen name="메인메뉴" component={HomeStack} />
      <Tab.Screen name="레시피" component={RecipesScreen} />
      <Tab.Screen name="냉장고" component={FridgeScreen} />
    </Tab.Navigator>
  );
};

export default TabNavigator;